#include <string.h>
#include <stdio.h>

int main () {
	char str[80] = "safiabaloch";
    char s[20] = "shaherbano";
    char *token;
    token = strtok(str, s);
    while( token != NULL ) {
    printf( " %s\n", token );
    token = strtok(NULL, s);
   }
   return(0);
}
