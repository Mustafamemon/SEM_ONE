#include<stdio.h>
int main()
{
	double x = 28 ;
	int r;
	r = (int)x % 5;
	printf("\n r = %d ",r) ;
}
