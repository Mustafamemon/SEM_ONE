#include<stdio.h>
main() 
{ 
	int x =753, y=722 ;  
	printf(" x & y is %d %d" , x ,y ); 
} 
