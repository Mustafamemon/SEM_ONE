#include<stdio.h>
void main ()
{
	int I=0x10+010+10 ;
	printf("\nx=%d",I);
}
