#include<stdio.h>
void main()
{	
	int a, b, c = 10 ; a, b, c = 50 ; 
	printf("\n %d %d %d ",a,b,c);
}
