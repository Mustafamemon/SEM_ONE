#include<stdio.h>
void main ( ) 
{ 
	printf("%d", 'B' < 'A' ); 
} 
