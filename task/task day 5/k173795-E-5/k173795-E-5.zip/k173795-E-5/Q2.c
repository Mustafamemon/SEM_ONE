#include<stdio.h>
int main ()
{
	int a, b, c  ;
	printf("enter your semster no :\n");
	scanf("%d", &a);
	printf("enter your register no :\n");
	scanf("%d",&b);
	c =a*b;
	printf("Your unique num is %d", c);
	return 0 ;
}
