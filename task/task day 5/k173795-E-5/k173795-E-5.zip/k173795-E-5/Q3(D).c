#include<stdio.h>
void main ()
{
	printf("\n ABC\b\b\bInfo World");
}
