
#include<stdio.h>
#include<math.h>
void main()
{
	int num,i,a=0,j ;
	printf("Enter The Num: ");
	scanf("%d",&num);
	for(i=0;i<=num;i++)
	{
		printf("2  Power %d =",i);
			{
				a=pow(2,i);
			}
		printf(" %d\n",a);
	}
}
	
