#include<stdio.h>
let_us_c();
main( ) 
{ 
let_us_c();
}
let_us_c( ) 
{ 
printf ( "\nC is a Cimple minded language !" ) ; 
printf ( "\nOthers are of course no match !" ) ; 
} 
