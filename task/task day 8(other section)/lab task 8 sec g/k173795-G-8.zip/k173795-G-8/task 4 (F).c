#include<stdio.h>
void message( ) ;
main( ) 
{ 
	message( ) ; 
	message ( );
} 
void message( ) 
{ 
printf ( "\nPraise worthy and C worthy are synonyms" ) ; 
}
