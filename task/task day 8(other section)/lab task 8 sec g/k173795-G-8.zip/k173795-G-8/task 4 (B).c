#include<stdio.h>
int message();
main( ) 
{    int a ;
a=message(a) ;	

} 

int message() 
{  
	int a ;
   printf ( "\nViruses are written in C",a) ; 
   return a;  
} 

