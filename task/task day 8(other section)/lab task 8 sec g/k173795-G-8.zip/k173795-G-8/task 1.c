#include<stdio.h>
int x (int y);
void main ()
{
	int y;
	printf("Enter the Year : ");
	scanf("%d",&y);
	x(y);
}
int x (int y)
{
	int rem=0,rev;
	if (y>=1000)
	{
		printf("m");
		x(y-1000);
		
	}
	else if (y>=500)
	{
		printf("d");
		x(y-500);
	}
	else if (y>=50)
	{
		printf("l");
		x(y-50);
	}
	else if (y>=10)
	{
			printf("x");
		x(y-10);
	}
	else if (y>=5)
	{
			printf("v");
		x(y-5);
	}
	else if (y>=1)
	{
			printf("i");
		x(y-1);
	}
}

	
