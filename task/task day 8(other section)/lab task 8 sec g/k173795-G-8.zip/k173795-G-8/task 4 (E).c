#include<stdio.h>
void main( ) 
{ 
message( ) ; 
message( ) ; 
} 
message( ) 
{ 
printf ( "\nPraise worthy and C worthy are synonyms" ) ; 
}