#include<stdio.h>
void main ()
{
	int num1,num2;
	printf("Enter the 1st number ");
	scanf("%d",&num1);
	printf("Enter the 2nd number ");
	scanf("%d",&num2);
	if (num1<num2)
	printf("Up");
	else if (num2<num1)
	printf("Down"); 
	else if (num1==num2)
	printf("Equal");
	else
	printf("Error");
}
